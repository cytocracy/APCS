import info.gridworld.actor.Critter;
import java.util.ArrayList;
import info.gridworld.actor.Actor;
import java.awt.Color;
import info.gridworld.grid.Location;

public class MaleFish extends Fish
{
    public MaleFish()
    {
        super();  // needed to call Fish constructor, which initializes age
        setColor(Color.BLUE);
    }

    // finish this up (actually, I think you're done)
}