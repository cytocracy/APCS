import java.awt.Color;

public class Sand extends Particle
{

    public Sand()
    {
        super(ParticlesProgram.SAND, Color.yellow);
    }


}
