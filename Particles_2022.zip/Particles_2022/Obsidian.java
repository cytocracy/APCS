import java.awt.Color;

public class Obsidian extends Particle
{

    public Obsidian()
    {
        super(ParticlesProgram.OBSIDIAN, Color.darkGray);
    }


}
