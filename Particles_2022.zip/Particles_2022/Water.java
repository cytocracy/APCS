import java.awt.Color;

public class Water extends Particle {
    public Water(){
        super(ParticlesProgram.WATER, Color.blue);
    }
}
