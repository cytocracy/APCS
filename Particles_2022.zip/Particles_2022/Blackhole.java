import java.awt.Color;

public class Blackhole extends Particle
{

    public Blackhole()
    {
        super(ParticlesProgram.BLACKHOLE, Color.darkGray);
    }


}
