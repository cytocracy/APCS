import java.awt.Color;

public class Wood extends Particle
{

    public Wood()
    {
        super(ParticlesProgram.WOOD, new Color(128, 70, 27));
    }


}
