

public class SmallAsteroid extends Asteroid
{
    public SmallAsteroid(int windowWidth, int windowHeight)
    {
        super(windowWidth, windowHeight);
        scale(0.25);
    }
}
