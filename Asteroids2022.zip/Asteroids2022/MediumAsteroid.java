

public class MediumAsteroid extends Asteroid
{
    public MediumAsteroid(int windowWidth, int windowHeight)
    {
        super(windowWidth, windowHeight);
        scale(0.5);
    }
}
