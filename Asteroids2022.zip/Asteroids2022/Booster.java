

public class Booster extends GVectorPolygon
{

    public Booster(int windowWidth, int windowHeight)
    {
        super(windowWidth, windowHeight);
        initVertices();
    }
    
    public void initVertices(){
        double[][] vertices = {
          {0, 0}
            
        };
    }
    


}
